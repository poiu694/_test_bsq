#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>

#include "bsq.h"

int	ft_open(char *path)
{
	int	fd;

	fd = open(path, O_RDONLY);
	if (fd == -1)
	{
		return (0);
	}
	return (fd);
}

int	ft_readline(int fd, char *buf)
{
	char	ch;
	int		len;

	len = 0;
	while (read(fd, &ch, 1))
	{
		if (ch == '\n')
		{
			buf[len] = 0;
			return (len + 1);
		}
		buf[len] = ch;
		len++;
	}
	buf[len] = 0;
	return (len);
}

//	TODO:	파일 끝까지 읽어 들인후 반환하는 함수를 구현하면 됨
char	**ft_read(int fd, int size)
{
	int		i;
	int		j;
	char	ch;
	char	**map;

	map = (char **)malloc((size + 1) * sizeof(char *));
	i = 0;
	while (i < size)
	{
		map[i] = (char *)malloc((size + 1) * sizeof(char));
		j = 0;
		while (read(fd, &ch, 1))
		{
			if (ch == '\n')
				break ;
			map[i][j] = ch;
			j++;
		}
		i++;
	}
	return (map);
}
