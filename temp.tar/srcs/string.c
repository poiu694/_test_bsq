int		ft_atoi(char *str)
{
	int	n;
	int	i;

	n = 0;
	i = 0;
	while (str[i] && (('0' <= str[i]) && (str[i] <= '9')))
	{
		n *= 10;
		n += str[i] - '0';
		i++;
	}
	return (n);
}
